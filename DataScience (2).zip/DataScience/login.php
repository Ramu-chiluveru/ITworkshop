<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Login</title>
</head>
<body>

  <?php
      if($_SERVER["REQUEST_METHOD"] == "POST")
      {
        $server = "localhost";
        $user = "root";
        $password = "*Ramu@2003#";
        $dbname = "login";

        $conn = new mysqli($server, $user, $password, $dbname);

        $mail = $_POST["mail"];
        $password = $_POST["password"];
        if($conn->error)
        {
          die("connection error: " . $conn->error);
        }

        $sql = "SELECT * FROM users WHERE mail = '$mail' AND password='$password'";
        $result = $conn->query($sql);

        if(!$result)
        {
          die("Invalid query: " . $conn->error);
        }

        if($result->num_rows > 0)
        {
          $row = $result->fetch_assoc();
          echo "Successfully logged in <h1>$row[mail]</h1>";
        }
        else
        {
          echo "<p>Invalid user details</p>";
        }
      }
  ?>

  <form action="" method="post">
    <input type="email" name="mail" id="username" required>
    <input type="password" name="password" id="password" required>
    <button type="submit">Login</button>
  </form>
  
</body>
</html>
